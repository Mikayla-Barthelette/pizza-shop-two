print("Pizza Order")
LABOUR_COST = 0.75
RENT_OF_SHOP = 1
Materials = float(input("Diameter of pizza in inches:"))
TAX = 1.13
Subtotal = LABOUR_COST + RENT_OF_SHOP + Materials*0.5
print("The subtotal of the pizza is:" ,LABOUR_COST, "dollars by" ,RENT_OF_SHOP, "dollars by" ,Materials, "dollars is" ,Subtotal, "dollars.")
Total = Subtotal*TAX
print("The total of the pizza is:" ,Subtotal, "dollars by" ,TAX, "dollars is" ,Total, "dollars.")
Rounded_total_1 = 100*Total
Rounded_total_2 = (round(Rounded_total_1))
Final_total = Rounded_total_2/100
print("The rounded total is: 100 times" ,Total, "rounded and divided by 100 equals" ,Final_total, "dollars")